@echo off
title Music Motion - quitar el icono .mmf
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0quitar-icono-mmf.ps1"
echo.
pause
