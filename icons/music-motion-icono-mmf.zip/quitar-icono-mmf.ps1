# Music Motion - devuelve el icono que tenian los .mmf / restores the previous .mmf icon
$dir = Join-Path $env:LOCALAPPDATA 'Music Motion'
$antes = Join-Path $dir 'icono-mmf-antes.txt'
if (-not (Test-Path $antes)) { $antes = Join-Path $PSScriptRoot 'icono-mmf-antes.txt' }
if (-not (Test-Path $antes)) { Write-Host 'No hay nada que devolver / nothing to restore'; exit 0 }
foreach ($l in Get-Content $antes) {
  $id, $v = $l -split '\|', 2
  $k = "HKCU:\Software\Classes\$id\DefaultIcon"
  if ($v) { Set-ItemProperty -Path $k -Name '(default)' -Value $v } else { Remove-Item -Path $k -ErrorAction SilentlyContinue }
  Write-Host "Devuelto / restored: $id"
}
Remove-Item $antes
Start-Process -FilePath "$env:WINDIR\System32\ie4uinit.exe" -ArgumentList '-show' -Wait -ErrorAction SilentlyContinue
Write-Host 'Listo / done.'
