# Music Motion - el icono naranja para los archivos .mmf (Windows) / the orange icon for .mmf files
# Copia mm-mmf.ico a %LOCALAPPDATA%\Music Motion y lo pone como icono de los .mmf, solo para este usuario.
# Copies mm-mmf.ico to %LOCALAPPDATA%\Music Motion and sets it as the .mmf icon, for this user only.
$src = Join-Path $PSScriptRoot 'mm-mmf.ico'
$dir = Join-Path $env:LOCALAPPDATA 'Music Motion'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$ico = Join-Path $dir 'mm-mmf.ico'
if (Test-Path $src) { Copy-Item $src $ico -Force }
if (-not (Test-Path $ico)) { Write-Host 'No encuentro mm-mmf.ico / mm-mmf.ico not found'; exit 1 }
$ids = @()
$uc = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.mmf\UserChoice' -ErrorAction SilentlyContinue
if ($uc -and $uc.ProgId) { $ids += $uc.ProgId }
$ow = Get-Item 'HKCU:\Software\Classes\.mmf\OpenWithProgids' -ErrorAction SilentlyContinue
if ($ow) { $ids += $ow.GetValueNames() | Where-Object { $_ } }
$def = (Get-ItemProperty 'HKCU:\Software\Classes\.mmf' -ErrorAction SilentlyContinue).'(default)'
if ($def) { $ids += $def }
$ids = $ids | Where-Object { $_ -and $_ -notlike 'Applications\*' } | Select-Object -Unique
if (-not $ids) {
  Write-Host 'Primero instala mm Score y abre un .mmf con el (Abrir con > mm Score > Usar siempre). Despues vuelve a correr esto.'
  Write-Host 'First install mm Score and open a .mmf with it (Open with > mm Score > Always). Then run this again.'
  exit 1 }
$antes = Join-Path $dir 'icono-mmf-antes.txt'
if (-not (Test-Path $antes)) {
  $ids | ForEach-Object { $k = "HKCU:\Software\Classes\$_\DefaultIcon"; $v = (Get-ItemProperty $k -ErrorAction SilentlyContinue).'(default)'; "$_|$v" } | Set-Content -Encoding UTF8 $antes
}
foreach ($id in $ids) {
  $k = "HKCU:\Software\Classes\$id\DefaultIcon"
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty -Path $k -Name '(default)' -Value "`"$ico`",0"
  Write-Host "Icono puesto / icon set: $id"
}
Start-Process -FilePath "$env:WINDIR\System32\ie4uinit.exe" -ArgumentList '-show' -Wait -ErrorAction SilentlyContinue
Write-Host ''
Write-Host 'Listo. Cierra la carpeta y vuelve a abrirla (o reinicia).'
Write-Host 'Done. Close the folder and open it again (or restart).'
