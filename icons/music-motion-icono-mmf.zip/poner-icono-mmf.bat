@echo off
title Music Motion - icono .mmf
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0poner-icono-mmf.ps1"
echo.
pause
