﻿# Quita los accesos directos que puso crear-accesos-music-motion.ps1 (2026-10-26)
$escritorio = [Environment]::GetFolderPath('Desktop')
foreach ($n in 'MM Score','MM Keyboard','MM Player','MM Console','MM Simulator','MM Coach','MM Tuner') {
  $l = Join-Path $escritorio ($n + '.lnk')
  if (Test-Path $l) { Remove-Item $l; Write-Host ('  ' + $n) }
}
Write-Host 'Listo. / Done.'
