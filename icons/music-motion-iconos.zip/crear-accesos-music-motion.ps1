﻿# Music Motion - accesos directos en el Escritorio (2026-10-26). Cada uno abre su app del sitio publicado
# (musicmotionsuite.com) en una ventana de Chrome sin barra de direcciones, con su propio icono.
# El Score y el Keyboard no van aqui: se instalan desde Chrome (menu > Instalar), que ademas registra los .mmf (2026-10-27).
# Los iconos se copian a %LOCALAPPDATA%\Music Motion\iconos, asi los accesos no dependen de esta carpeta.
$ErrorActionPreference = 'Stop'
$aqui = $PSScriptRoot
$destino = Join-Path $env:LOCALAPPDATA 'Music Motion\iconos'
New-Item -ItemType Directory -Force -Path $destino | Out-Null

$navegador = @(
  (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $navegador) { Write-Host 'No encuentro Chrome ni Edge. / Chrome or Edge not found.'; exit 1 }

$sitio = 'https://musicmotionsuite.com/apps/'
$apps = @(
  @('MM Player',    ($sitio + 'mm-player.html'),             'mm-player.ico'),
  @('MM Console',   ($sitio + 'mm-console.html'),            'mm-console.ico'),
  @('MM Simulator', ($sitio + 'mm-register-simulator.html'), 'mm-simulator.ico'),
  @('MM Coach',     ($sitio + 'mm-coach.html'),              'mm-coach.ico'),
  @('MM Tuner',     'https://tuner.mariomaurano.com/',       'mm-tuner.ico')
)
$escritorio = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
foreach ($a in $apps) {
  $ico = Join-Path $destino $a[2]
  Copy-Item -Force (Join-Path $aqui $a[2]) $ico
  $s = $ws.CreateShortcut((Join-Path $escritorio ($a[0] + '.lnk')))
  $s.TargetPath = $navegador
  $s.Arguments = '--app=' + $a[1]
  $s.WorkingDirectory = $destino
  $s.IconLocation = $ico + ',0'
  $s.Description = 'Music Motion - ' + $a[0]
  $s.Save()
  Write-Host ('  ' + $a[0])
}
ie4uinit.exe -show 2>$null
Write-Host ''
Write-Host 'Listo: 5 accesos en el Escritorio. / Done: 5 shortcuts on the Desktop.'
