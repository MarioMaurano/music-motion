@echo off
title Music Motion - quitar iconos
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0quitar-icono-mmf.ps1"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0quitar-accesos-music-motion.ps1"
echo.
pause
