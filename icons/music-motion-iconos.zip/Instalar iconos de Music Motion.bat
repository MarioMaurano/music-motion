@echo off
title Music Motion - iconos
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0poner-icono-mmf.ps1"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0crear-accesos-music-motion.ps1"
echo.
pause
